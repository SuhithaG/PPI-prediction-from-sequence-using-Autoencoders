Online support information A
There are 36,630 protein-protein pairs from total 9476 proteins, and the first column is protein ID from HPRD, the second column is the other protein ID and the two proteins constitute the positive Protein-protein interaction.
Online support information B
There are 36,480 protein-protein pairs from total 2184 proteins, and the first column is protein ID, the second column is the other protein ID and the two proteins constitute the negative Protein-protein interaction.
Online support information C
There are 3899 protein-protein pairs from total 2502 proteins, and the first column is protein ID from HPRD, the second column is the other protein ID and the two proteins constitute the positive Protein-protein interaction and protein identity of all the proteins from Supp-C and Supp-D is below 25%;
Online support information D
There are 4262 protein-protein pairs from total 661 proteins, and the first column is protein ID from HPRD, the second column is the other protein ID and the two proteins constitute the positive Protein-protein interaction and protein identity of all the proteins from Supp-C and Supp-D is below 25%;
Online support information E
There are 1,882 human protein-protein pairs from total 842 proteins, and the first 50% of the pairs are interacting proteins，the last 50% are the non-interacting proteins.
